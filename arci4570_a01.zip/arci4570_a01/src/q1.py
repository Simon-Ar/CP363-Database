"""
-------------------------------------------------------
[file name]
[program description]
-------------------------------------------------------
Author:  Simon Arcila
ID:        130804570
Email:   arci4570@mylaurier.ca
__updated__ = "2019-01-28"
-------------------------------------------------------
"""

from asgn01 import keyword_table
from connect import Connect

keyid = 7
rows = []
connection = Connect('dcris.txt')

rows = keyword_table(connection)

for i in rows:
    print(i)
print('--------------------')
connection = Connect('dcris.txt')
rows = keyword_table(connection,keyid)

for i in rows:
    print(i)