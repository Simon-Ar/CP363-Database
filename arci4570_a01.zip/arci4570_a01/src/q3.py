"""
-------------------------------------------------------
[file name]
[program description]
-------------------------------------------------------
Author:  Simon Arcila
ID:        130804570
Email:   arci4570@mylaurier.ca
__updated__ = "2019-01-28"
-------------------------------------------------------
"""

from asgn01 import member_expertise
from connect import Connect

member_id = 33
keyword_id = 7
rows = []
connection = Connect('dcris.txt')

rows = member_expertise(connection, member_id)

for i in rows:
    print(i)
    
print('---------------------------------')

connection = Connect('dcris.txt')
rows = member_expertise(connection,None, keyword_id)

for i in rows:
    print(i)

print('-------------------------------------')

    
connection = Connect('dcris.txt')
rows = member_expertise(connection, member_id, keyword_id)

for i in rows:
    print(i)
    
print('----------------------------------------')


connection = Connect('dcris.txt')
rows = member_expertise(connection)

for i in rows:
    print(i)