"""
-------------------------------------------------------
[file name]
[program description]
-------------------------------------------------------
Author:  Simon Arcila
ID:        130804570
Email:   arci4570@mylaurier.ca
__updated__ = "2019-01-28"
-------------------------------------------------------
"""

from asgn01 import expertise
from connect import Connect

keyword = "doc"
supp_key = "am"
rows = []
connection = Connect('dcris.txt')

rows = expertise(connection, keyword)

for i in rows:
    print(i)
    
print('---------------------------------')

connection = Connect('dcris.txt')
rows = expertise(connection,None, supp_key)

for i in rows:
    print(i)

print('-------------------------------------')

    
connection = Connect('dcris.txt')
rows = expertise(connection, keyword, supp_key)

for i in rows:
    print(i)
    
print('----------------------------------------')


connection = Connect('dcris.txt')
rows = expertise(connection)

for i in rows:
    print(i)