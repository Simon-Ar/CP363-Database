"""
-------------------------------------------------------
[file name]
[program description]
-------------------------------------------------------
Author:  Simon Arcila
ID:        130804570
Email:   arci4570@mylaurier.ca
__updated__ = "Feb. 25, 2019"
-------------------------------------------------------
"""
def pub_counts_all(conn, member_id=None):
    """
    -------------------------------------------------------
    Queries the pub and member tables.
    Use: rows = pub_counts(conn)
    Use: rows = pub_counts(conn, member_id=v1)
    -------------------------------------------------------
    Parameters:
        conn - a database connection (Connect)
        member_id - a member ID number (int)
    Returns:
        rows - a list with a member's last name, a member's first
        name, and the number of publications of each type. Name these
        three fields "articles", "papers", and "books". List the results
        as appropriate in order by member last name and first name.
        If member_id is None, list all members. (list of ?)
    -------------------------------------------------------
    """
    
    if (member_id is None):
        sql ="""SELECT m.last_name, m.first_name,
                COUNT(CASE WHEN p.pub_type_id = 'a' ELSE NULL END) AS article,
                COUNT(CASE WHEN p.pub_type_id = 'p' ELSE NULL END) AS papers,
                COUNT(CASE WHEN p.pub_type_id = 'b' ELSE NULL END) AS books,
                FROM member AS m
                JOIN (pub AS p) ON p.member_id = m.member_id
                GROUP BY m.last_name, m.first_name"""
        conn.cursor.execute(sql)
        rows = conn.cursor.fetch_all()
        
    else:
        sql ="""SELECT m.last_name, m.first_name,
                COUNT(CASE WHEN p.pub_type_id = 'a' ELSE NULL END) AS article,
                COUNT(CASE WHEN p.pub_type_id = 'p' ELSE NULL END) AS papers,
                COUNT(CASE WHEN p.pub_type_id = 'b' ELSE NULL END) AS books,
                FROM member AS m
                JOIN (pub AS p) ON p.member_id = m.member_id
                WHERE member_id = %s"""
        params = [member_id]
        conn.cursor.execute(sql,params)
        rows = conn.cursor.fetch_all()   
    return rows
        
def expertise_count(conn, member_id=None):
    """
    -------------------------------------------------------
    Use: rows = expertise_count(conn)
    Use: rows = expertise_count(conn, member_id=v1)
    -------------------------------------------------------
    Parameters:
        conn - a database connection (Connect)
        member_id - a member ID number (int)
    Returns:
        rows - a list with a member's last name, a member's first
        name, and the number of keywords and supplementary keywords
        for the member. Name these fields "keywords" and "supp_keys".
        List the results as appropriate in order by member last 
        name and first name. If member_id is None, list all members.
        (list of ?)
    -------------------------------------------------------
    """
    
    if (member_id is None):
        sql ="""SELECT m.last_name, m.first_name,
                COUNT(DISTINCT vmsk.keyword_id) AS keyword,
                COUNT(DISTINCT vmsk.supp_key_id) AS supp_keys
                FROM member AS m
                JOIN (v_member_supp_key AS vmsk) ON vmsk.member_id = m.member_id
                GROUP BY m.last_name, m.first_name"""
        conn.cursor.execute(sql)
        rows = conn.cursor.fetch_all()
        
    else:
        sql ="""SELECT m.last_name, m.first_name,
                COUNT(DISTINCT vmsk.keyword_id) AS keyword,
                COUNT(DISTINCT vmsk.supp_key_id) AS supp_keys
                FROM member AS m
                JOIN (v_member_supp_key AS vmsk) ON vmsk.member_id = m.member_id
                WHERE m.member_id = %s
                ORDER BY m.last_name, m.first_name"""
        params = [member_id]
        conn.cursor.execute(sql,params)
        rows = conn.cursor.fetch_all()   
    return rows

def keyword_count(conn, keyword_id=None):
    """
    -------------------------------------------------------
    Use: rows = keyword_count(conn)
    Use: rows = keyword_count(conn, keyword_id=v1)
    -------------------------------------------------------
    Parameters:
        conn - a database connection (Connect)
        keyword_id - a keyword ID number (int)
    Returns:
        rows - a list with a keyword's description and the number of
        supplementary keywords that belong to it. Name the second field
        "supp_key_count".
        List the results as appropriate in order by keyword description. 
        If keyword_id is None, list all keywords. (list of ?)
    -------------------------------------------------------
    """
    
    if (keyword_id is None):
        sql ="""SELECT vksk.k_desc,
                COUNT(DISTINCT vksk.supp_key_id) AS supp_key_count
                FROM v_keyword_supp_key AS vksk
                GROUP BY vksk.k_desc"""
        conn.cursor.execute(sql)
        rows = conn.cursor.fetch_all()
        
    else:
        sql ="""SELECT vksk.k_desc,
                COUNT(DISTINCT vksk.supp_key_id) AS supp_key_count
                FROM v_keyword_supp_key AS vksk
                WHERE vksk.keyword_id = %s"""
        params = [keyword_id]
        conn.cursor.execute(sql,params)
        rows = conn.cursor.fetch_all()   
    return rows

def keyword_member_count(conn, keyword_id=None):
    """
    -------------------------------------------------------
    Use: rows = keyword_member_count(conn)
    Use: rows = keyword_member_count(conn, keyword_id=v1)
    -------------------------------------------------------
    Parameters:
        conn - a database connection (Connect)
        keyword_id - a keyword ID number (int)
    Returns:
        rows - a list with a keyword's description and the number of
        members that have it. Name the second field
        "member_count".
        List the results as appropriate in order by keyword description. 
        If keyword_id is None, list all keywords. (list of ?)
    -------------------------------------------------------
    """
    
    if (keyword_id is None):
        sql ="""SELECT vmk.k_desc,
                COUNT(DISTINCT vmk.member_id) AS member_count
                FROM v_member_keyword AS vmk
                GROUP BY vmk.k_desc"""
        conn.cursor.execute(sql)
        rows = conn.cursor.fetch_all()
        
    else:
        sql ="""SELECT vmk.k_desc,
                COUNT(DISTINCT vmk.member_id) AS member_count
                FROM v_member_keyword AS vmk
                WHERE vmk.keyword_id = %s"""
        params = [keyword_id]
        conn.cursor.execute(sql,params)
        rows = conn.cursor.fetch_all()   
    return rows

def supp_key_member_count(conn, supp_key_id=None):
    """
    -------------------------------------------------------
    Use: rows = supp_key_member_count(conn)
    Use: rows = supp_key_member_count(conn, supp_key_id=v1)
    -------------------------------------------------------
    Parameters:
        conn - a database connection (Connect)
        supp_key_id - a supp_key ID number (int)
    Returns:
        rows - a list with a keyword's description, a supplementary
        keyword description, and the number of members that have it. 
        Name the last field "member_count".
        List the results as appropriate in order by keyword description
        and then supplementary keyword description.
        If supp_key_id is None, list all keywords and supplementary
        keywords. (list of ?)
    -------------------------------------------------------
    """
    if (supp_key_id is None):
        sql ="""SELECT vmsk.k_desc,vmsk.sk_desc
                COUNT(DISTINCT vmsk.member_id) AS member_count
                FROM v_member_supp_key AS vmsk
                GROUP BY vmsk.sk_desc"""
        conn.cursor.execute(sql)
        rows = conn.cursor.fetch_all()
        
    else:
        sql ="""SELECT vmsk.k_desc,vmsk.sk_desc
                COUNT(DISTINCT vmsk.member_id) AS member_count
                FROM v_member_supp_key AS vmsk
                WHERE vmk.keyword_id = %s"""
        params = [supp_key_id]
        conn.cursor.execute(sql,params)
        rows = conn.cursor.fetch_all()   
    return rows